import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:stay_connected/Platform/snapchat/snapchat_controller.dart';
import 'package:stay_connected/util/webview_dark_theme_helper.dart';

class SnapchatWebviewScreen extends StatefulWidget {
  final String searchQuery;
  final String iconName;
  final String platformName;

  const SnapchatWebviewScreen({
    super.key,
    required this.searchQuery,
    required this.iconName,
    required this.platformName,
  });

  @override
  State<SnapchatWebviewScreen> createState() => _SnapchatWebviewScreenState();
}

class _SnapchatWebviewScreenState extends State<SnapchatWebviewScreen> {
  InAppWebViewController? webViewController;
  bool isLoading = true;
  String? currentUrl;
  int loadingProgress = 0;

  String _getInitialUrl() {
    String query = widget.searchQuery;
    if (query.isNotEmpty) {
      query = '$query site:snapchat.com';
    }
    return 'https://www.google.com/search?q=${Uri.encodeComponent(query)}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    
    String userAgent = Platform.isIOS
        ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1'
        : 'Mozilla/5.0 (Linux; Android 14; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.iconName),
        centerTitle: true,
        backgroundColor: theme.appBarTheme.backgroundColor ?? (isDark ? Colors.grey[900] : Colors.yellow),
        foregroundColor: theme.appBarTheme.foregroundColor ?? (isDark ? Colors.grey[300] : Colors.black),
      ),
      body: Stack(
        children: [
          InAppWebView(
            initialUrlRequest: URLRequest(
              url: WebUri(_getInitialUrl()),
              headers: {
                'User-Agent': userAgent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
              },
            ),
            initialSettings: InAppWebViewSettings(
              userAgent: userAgent,
              javaScriptEnabled: true,
              allowsInlineMediaPlayback: true,
              mediaPlaybackRequiresUserGesture: false,
              useShouldOverrideUrlLoading: true,
            ),
            onWebViewCreated: (controller) {
              webViewController = controller;
              
              // Inject dark theme CSS at document start if dark mode is enabled
              if (Theme.of(context).brightness == Brightness.dark) {
                controller.addUserScript(userScript: WebViewDarkThemeHelper.getDarkThemeUserScript());
              }
              
              // Inject blocking script at document start
              controller.addUserScript(
                userScript: UserScript(
                  source: '''
                    (function() {
                      if (window.snapchatBlockingLoaded) return;
                      window.snapchatBlockingLoaded = true;
                      
                      // Block all clicks that would open Snapchat app
                      document.addEventListener('click', function(e) {
                        let target = e.target;
                        let depth = 0;
                        while (target && target !== document && depth < 10) {
                          if (target.tagName === 'A' && target.href) {
                            const href = target.href.toLowerCase();
                            if (href.startsWith('snapchat://') ||
                                href.includes('applink.snapchat.com') ||
                                href.includes('apps.apple.com') ||
                                href.includes('itunes.apple.com') ||
                                href.startsWith('itms://') ||
                                href.startsWith('itms-apps://') ||
                                href.includes('play.google.com/store') ||
                                href.startsWith('market://')) {
                              e.preventDefault();
                              e.stopPropagation();
                              e.stopImmediatePropagation();
                              return false;
                            }
                          }
                          target = target.parentElement;
                          depth++;
                        }
                      }, true);
                      
                      // Override window.open
                      const originalOpen = window.open;
                      window.open = function(url, target, features) {
                        if (url) {
                          const urlLower = url.toLowerCase();
                          if (urlLower.startsWith('snapchat://') ||
                              urlLower.includes('applink.snapchat.com') ||
                              urlLower.includes('apps.apple.com') ||
                              urlLower.includes('itunes.apple.com')) {
                            return null;
                          }
                        }
                        return originalOpen.call(window, url, target, features);
                      };
                    })();
                  ''',
                  injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                ),
              );
            },
            onLoadStart: (controller, url) {
              setState(() {
                isLoading = true;
                loadingProgress = 0;
                currentUrl = url?.toString();
              });
              
              // Inject dark theme CSS early if dark mode is enabled
              if (Theme.of(context).brightness == Brightness.dark) {
                WebViewDarkThemeHelper.injectDarkTheme(controller, context);
              }
              
              // Inject blocking script early
              controller.evaluateJavascript(source: '''
                (function() {
                  // Block all clicks that would open Snapchat app
                  document.addEventListener('click', function(e) {
                    let target = e.target;
                    let depth = 0;
                    while (target && target !== document && depth < 10) {
                      if (target.tagName === 'A' && target.href) {
                        const href = target.href.toLowerCase();
                        if (href.startsWith('snapchat://') ||
                            href.includes('applink.snapchat.com') ||
                            href.includes('apps.apple.com') ||
                            href.includes('itunes.apple.com') ||
                            href.startsWith('itms://') ||
                            href.startsWith('itms-apps://') ||
                            href.includes('play.google.com/store') ||
                            href.startsWith('market://')) {
                          e.preventDefault();
                          e.stopPropagation();
                          e.stopImmediatePropagation();
                          return false;
                        }
                      }
                      target = target.parentElement;
                      depth++;
                    }
                  }, true);
                })();
              ''');
            },
            onLoadStop: (controller, url) async {
              setState(() {
                isLoading = false;
                loadingProgress = 100;
                currentUrl = url?.toString();
              });
              
              // Inject dark theme CSS after page loads
              await WebViewDarkThemeHelper.injectDarkTheme(controller, context);
              
              // Inject blocking script again after page loads
              await controller.evaluateJavascript(source: '''
                (function() {
                  // Block all clicks that would open Snapchat app
                  document.addEventListener('click', function(e) {
                    let target = e.target;
                    let depth = 0;
                    while (target && target !== document && depth < 10) {
                      if (target.tagName === 'A' && target.href) {
                        const href = target.href.toLowerCase();
                        if (href.startsWith('snapchat://') ||
                            href.includes('applink.snapchat.com') ||
                            href.includes('apps.apple.com') ||
                            href.includes('itunes.apple.com') ||
                            href.startsWith('itms://') ||
                            href.startsWith('itms-apps://') ||
                            href.includes('play.google.com/store') ||
                            href.startsWith('market://')) {
                          e.preventDefault();
                          e.stopPropagation();
                          e.stopImmediatePropagation();
                          return false;
                        }
                      }
                      target = target.parentElement;
                      depth++;
                    }
                  }, true);
                  
                  // Override window.open
                  const originalOpen = window.open;
                  window.open = function(url, target, features) {
                    if (url) {
                      const urlLower = url.toLowerCase();
                      if (urlLower.startsWith('snapchat://') ||
                          urlLower.includes('applink.snapchat.com') ||
                          urlLower.includes('apps.apple.com') ||
                          urlLower.includes('itunes.apple.com')) {
                        return null;
                      }
                    }
                    return originalOpen.call(window, url, target, features);
                  };
                })();
              ''');
            },
            onProgressChanged: (controller, progress) {
              setState(() {
                loadingProgress = progress.toInt();
                if (progress >= 100) {
                  isLoading = false;
                }
              });
            },
            shouldOverrideUrlLoading: (controller, navigationAction) async {
              final url = navigationAction.request.url?.toString() ?? '';
              final urlLower = url.toLowerCase();
              
              print('Snapchat WebView - Navigation request to: $url');
              
              // Block applink.snapchat.com URLs (Universal Links)
              if (urlLower.contains('applink.snapchat.com')) {
                print('Snapchat WebView - Blocking applink URL: $url');
                return NavigationActionPolicy.CANCEL;
              }
              
              // Block URLs with launch_app_store parameter
              if (urlLower.contains('launch_app_store=true')) {
                print('Snapchat WebView - Blocking URL with launch_app_store: $url');
                return NavigationActionPolicy.CANCEL;
              }
              
              // Block Snapchat app schemes and App Store URLs
              if (urlLower.startsWith('snapchat://') ||
                  urlLower.contains('apps.apple.com') ||
                  urlLower.contains('itunes.apple.com') ||
                  urlLower.startsWith('itms://') ||
                  urlLower.startsWith('itms-apps://') ||
                  urlLower.contains('play.google.com/store') ||
                  urlLower.startsWith('market://')) {
                print('Snapchat WebView - Blocking app scheme/App Store URL: $url');
                return NavigationActionPolicy.CANCEL;
              }
              
              // For Snapchat URLs, ensure _webview=1&noapp=1 parameters are present
              if (urlLower.contains('snapchat.com') &&
                  !urlLower.contains('_webview=1') &&
                  !urlLower.contains('noapp=1')) {
                print('Snapchat WebView - Modifying URL to prevent Universal Links: $url');
                final modifiedUrl = url.contains('?')
                    ? '$url&_webview=1&noapp=1'
                    : '$url?_webview=1&noapp=1';
                Future.microtask(() async {
                  await controller.loadUrl(urlRequest: URLRequest(url: WebUri(modifiedUrl)));
                });
                return NavigationActionPolicy.CANCEL;
              }
              
              // Allow all other navigation
              return NavigationActionPolicy.ALLOW;
            },
            onReceivedServerTrustAuthRequest: (controller, challenge) async {
              return ServerTrustAuthResponse(action: ServerTrustAuthResponseAction.PROCEED);
            },
          ),
          if (isLoading)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(
                    'Loading: $loadingProgress%',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: isDark ? Colors.grey[400] : Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          // Always show Add Friend button at bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isDark ? Colors.grey[900] : Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 4,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: SafeArea(
                child: ElevatedButton(
                  onPressed: _isOnGoogleSearch() || isLoading
                      ? null
                      : () => _showAddFriendDialog(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isDark ? Colors.grey[800] : Colors.black,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: Colors.grey.shade400,
                    disabledForegroundColor: Colors.grey.shade600,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.person_add,
                        color: (_isOnGoogleSearch() || isLoading)
                            ? Colors.grey.shade600
                            : Colors.white,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isLoading
                            ? 'Loading: $loadingProgress%'
                            : 'Add Friend',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: (_isOnGoogleSearch() || isLoading)
                              ? Colors.grey.shade600
                              : Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  bool _isOnGoogleSearch() {
    final url = currentUrl?.toLowerCase() ?? '';
    return url.contains('google.com') || url.contains('googleapis.com');
  }

  void _showAddFriendDialog() async {
    // Don't show dialog if on Google search page
    if (_isOnGoogleSearch()) {
      Get.snackbar(
        'Error',
        'Please navigate to a Snapchat profile page first',
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    final nameController = TextEditingController();

    String? actualCurrentUrl;
    try {
      if (webViewController != null) {
        actualCurrentUrl = (await webViewController!.getUrl())?.toString();
      } else {
        actualCurrentUrl = currentUrl;
      }
    } catch (e) {
      actualCurrentUrl = currentUrl;
    }

    // Double check it's not a Google search page
    if (_isOnGoogleSearch()) {
      Get.snackbar(
        'Error',
        'Please navigate to a Snapchat profile page first',
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    String extractedName = '';
    if (actualCurrentUrl != null) {
      extractedName =
          _extractNameFromUrl(actualCurrentUrl) ?? widget.searchQuery;
    } else {
      extractedName = widget.searchQuery;
    }

    nameController.text = extractedName;

    showCupertinoDialog(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: CupertinoColors.systemYellow.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  CupertinoIcons.person_add,
                  color: CupertinoColors.systemYellow,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Add Friend',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          content: Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Column(
              children: [
                Text(
                  'Add this person to your ${widget.iconName} list?',
                  style: const TextStyle(
                    fontSize: 14,
                    color: CupertinoColors.systemGrey,
                  ),
                ),
                const SizedBox(height: 16),
                CupertinoTextField(
                  controller: nameController,
                  autofocus: true,
                  placeholder: 'Friend Name',
                  maxLength: 10,
                  decoration: BoxDecoration(
                    color: CupertinoColors.systemGrey6,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 12,
                  ),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Current URL: ${actualCurrentUrl ?? "Loading..."}',
                  style: const TextStyle(
                    fontSize: 10,
                    color: CupertinoColors.systemGrey2,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            CupertinoDialogAction(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text(
                'Cancel',
                style: TextStyle(
                  color: CupertinoColors.systemGrey,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            CupertinoDialogAction(
              onPressed: () {
                if (nameController.text.trim().isNotEmpty) {
                  Navigator.of(context).pop();
                  _addFriendToIcon(
                      nameController.text.trim(), actualCurrentUrl);
                }
              },
              isDefaultAction: true,
              child: const Text(
                'Add',
                style: TextStyle(
                  color: CupertinoColors.systemYellow,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _addFriendToIcon(String friendName, String? profileUrl) {
    String finalProfileUrl = profileUrl ??
        'https://www.snapchat.com/add/${Uri.encodeComponent(friendName)}';

    final controller = Get.find<SnapchatController>();
    controller.addFriendToCategory(
        friendName, widget.iconName, finalProfileUrl);

    Get.back();

    Get.snackbar(
      'Friend Added Successfully!',
      '$friendName has been added to your ${widget.iconName} list',
      snackPosition: SnackPosition.BOTTOM,
      duration: const Duration(seconds: 2),
      backgroundColor: Colors.green,
      colorText: Colors.white,
      margin: const EdgeInsets.all(10),
      borderRadius: 10,
    );
  }

  String? _extractNameFromUrl(String url) {
    if (url.contains('snapchat.com/')) {
      String path = url.split('snapchat.com/')[1];
      if (path.isNotEmpty) {
        String username = path.split('?')[0].split('/')[0];
        if (username != 'add' &&
            username != 'discover' &&
            username != 'stories' &&
            username != 'map' &&
            username != 'memories' &&
            username != 'spotlight' &&
            username != 'games' &&
            username != 'minis') {
        return username.replaceAll('-', ' ').replaceAll('_', ' ');
        }
      }
    }
    return null;
  }
}
