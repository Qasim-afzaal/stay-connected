class HttpUtil {
  static String name = "name";
  static String firstName = "firstname";
  static String lastName = "lastname";
  static String email = "email";
  static String password = "password";
  static String authProvider = "auth_provider";
  static String gender = "gender";
  static String age = "age";
  static String personalityType = "personality_type";
  static String profileImageUrl = "profile_image_url";
  static String otp = "otp";
  static String pin = "pin";
  static String newPin = "newPin";
  static String oldPin = "oldPin";
  static String deviceId = "device_id";
  static String isForgetPin = "isForgetPin";
  static String conversationId = "conversation_id";
}
